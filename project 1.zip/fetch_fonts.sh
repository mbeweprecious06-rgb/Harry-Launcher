#!/bin/bash
# Downloads free Google Fonts (open licences) into the app, up to 50 fonts.
A=app/src/main/assets
OUT=$A/fonts
mkdir -p "$OUT"
LIST="pacifico/Pacifico-Regular lobster/Lobster-Regular indieflower/IndieFlower-Regular permanentmarker/PermanentMarker-Regular bangers/Bangers-Regular righteous/Righteous-Regular satisfy/Satisfy-Regular anton/Anton-Regular bebasneue/BebasNeue-Regular abrilfatface/AbrilFatface-Regular alfaslabone/AlfaSlabOne-Regular amaticsc/AmaticSC-Regular archivoblack/ArchivoBlack-Regular arvo/Arvo-Regular bevan/Bevan-Regular chewy/Chewy-Regular creepster/Creepster-Regular greatvibes/GreatVibes-Regular kaushanscript/KaushanScript-Regular lobstertwo/LobsterTwo-Regular luckiestguy/LuckiestGuy-Regular monoton/Monoton-Regular pressstart2p/PressStart2P-Regular rocksalt/RockSalt-Regular russoone/RussoOne-Regular sacramento/Sacramento-Regular specialelite/SpecialElite-Regular staatliches/Staatliches-Regular ubuntu/Ubuntu-Regular ubuntumono/UbuntuMono-Regular vt323/VT323-Regular yellowtail/Yellowtail-Regular zillaslab/ZillaSlab-Regular bungee/Bungee-Regular courgette/Courgette-Regular cookie/Cookie-Regular allura/Allura-Regular audiowide/Audiowide-Regular blackopsone/BlackOpsOne-Regular crimsontext/CrimsonText-Regular electrolize/Electrolize-Regular fjallaone/FjallaOne-Regular gochihand/GochiHand-Regular kalam/Kalam-Regular lato/Lato-Regular molengo/Molengo-Regular oleoscript/OleoScript-Regular play/Play-Regular poiretone/PoiretOne-Regular rubikmonoone/RubikMonoOne-Regular sigmarone/SigmarOne-Regular titanone/TitanOne-Regular tradewinds/TradeWinds-Regular philosopher/Philosopher-Regular poppins/Poppins-Regular chakrapetch/ChakraPetch-Regular kanit/Kanit-Regular prompt/Prompt-Regular sarabun/Sarabun-Regular mali/Mali-Regular itim/Itim-Regular pattaya/Pattaya-Regular shadowsintolight/ShadowsIntoLight-Regular patrickhand/PatrickHand-Regular architectsdaughter/ArchitectsDaughter-Regular cherrybombone/CherryBombOne-Regular fascinate/Fascinate-Regular frijole/Frijole-Regular nosifer/Nosifer-Regular"

: > "$A/fonts.css"
echo "window.HL_FONTS=[" > "$A/fonts.js"
n=0
for item in $LIST; do
  [ "$n" -ge 50 ] && break
  dir=${item%%/*}
  file=${item##*/}
  ok=0
  for lic in ofl apache ufl; do
    if curl -fsSL --max-time 30 -o "$OUT/$file.ttf" "https://raw.githubusercontent.com/google/fonts/main/$lic/$dir/$file.ttf"; then
      ok=1
      break
    fi
  done
  if [ "$ok" -eq 1 ] && [ -s "$OUT/$file.ttf" ]; then
    name=$(echo "${file%-Regular}" | sed -E 's/([a-z0-9])([A-Z])/\1 \2/g')
    echo "{n:\"$name\",f:\"HLF$n\"}," >> "$A/fonts.js"
    echo "@font-face{font-family:'HLF$n';src:url('fonts/$file.ttf');font-display:swap}" >> "$A/fonts.css"
    n=$((n+1))
  else
    rm -f "$OUT/$file.ttf"
    echo "skipped $item"
  fi
done
echo "];" >> "$A/fonts.js"
echo "Fonts downloaded: $n"
