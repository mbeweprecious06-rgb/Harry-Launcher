package com.harry.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int FILE_REQ = 11;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private final Map<String, byte[]> cache = new HashMap<String, byte[]>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return icon(r.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) {
                    fileCb.onReceiveValue(null);
                }
                fileCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    startActivityForResult(Intent.createChooser(i, "Choose image"), FILE_REQ);
                } catch (Exception e) {
                    fileCb = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == FILE_REQ && fileCb != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                r = new Uri[]{data.getData()};
            }
            fileCb.onReceiveValue(r);
            fileCb = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (web != null && Intent.ACTION_MAIN.equals(intent.getAction())) {
            web.evaluateJavascript("window.goHome&&window.goHome()", null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.evaluateJavascript("window.refreshApps&&window.refreshApps()", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("window.onBack&&window.onBack()", null);
        }
    }

    // ---------- icons ----------

    private WebResourceResponse icon(Uri u) {
        if (u != null && "icons.local".equals(u.getHost())) {
            String pkg = u.getLastPathSegment();
            if (pkg != null) {
                byte[] bytes = iconBytes(pkg);
                return new WebResourceResponse("image/png", null, new ByteArrayInputStream(bytes));
            }
        }
        return null;
    }

    private byte[] iconBytes(String pkg) {
        synchronized (cache) {
            byte[] c = cache.get(pkg);
            if (c != null) {
                return c;
            }
        }
        try {
            Drawable d = getPackageManager().getApplicationIcon(pkg);
            int s = 144;
            Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(bm);
            d.setBounds(0, 0, s, s);
            d.draw(cv);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, o);
            bm.recycle();
            byte[] r = o.toByteArray();
            synchronized (cache) {
                cache.put(pkg, r);
            }
            return r;
        } catch (Throwable e) {
            return new byte[0];
        }
    }

    private int dimen(String name) {
        int id = getResources().getIdentifier(name, "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    // ---------- bridge to the HTML interface ----------

    private class Bridge {

        @JavascriptInterface
        public String getApps() {
            try {
                PackageManager pm = getPackageManager();
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
                JSONArray arr = new JSONArray();
                Set<String> seen = new HashSet<String>();
                for (ResolveInfo ri : list) {
                    String p = ri.activityInfo.packageName;
                    if (p.equals(getPackageName()) || !seen.add(p)) {
                        continue;
                    }
                    ApplicationInfo ai = ri.activityInfo.applicationInfo;
                    int cat = -1;
                    if (Build.VERSION.SDK_INT >= 26) {
                        cat = ai.category;
                    }
                    if (cat < 0 && (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0) {
                        cat = 0;
                    }
                    JSONObject o = new JSONObject();
                    o.put("n", ri.loadLabel(pm).toString());
                    o.put("p", p);
                    o.put("c", cat);
                    arr.put(o);
                }
                return arr.toString();
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface
        public void launch(final String p) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = getPackageManager().getLaunchIntentForPackage(p);
                        if (i != null) {
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        }
                    } catch (Exception e) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void appInfo(final String p) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + p));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void uninstall(final String p) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + p));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void openHomeSettings() {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent(Settings.ACTION_SETTINGS));
                        } catch (Exception e2) {
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public String getInsets() {
            float d = getResources().getDisplayMetrics().density;
            int top = Math.round(dimen("status_bar_height") / d);
            int bottom = Math.round(dimen("navigation_bar_height") / d);
            return top + "," + bottom;
        }

        @JavascriptInterface
        public void setLightStatus(final boolean light) {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (Build.VERSION.SDK_INT >= 23) {
                        View d = getWindow().getDecorView();
                        int f = d.getSystemUiVisibility();
                        if (light) {
                            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        } else {
                            f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        }
                        d.setSystemUiVisibility(f);
                    }
                }
            });
        }

        @JavascriptInterface
        public String getBattery() {
            try {
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b == null) {
                    return "100,1";
                }
                int lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 100);
                int sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING
                        || st == BatteryManager.BATTERY_STATUS_FULL;
                return (lv * 100 / Math.max(sc, 1)) + "," + (ch ? 1 : 0);
            } catch (Exception e) {
                return "100,1";
            }
        }
    }
}
